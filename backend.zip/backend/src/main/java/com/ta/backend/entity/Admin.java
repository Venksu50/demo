package com.ta.backend.entity;

public class Admin {

}
