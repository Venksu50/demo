import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AddEmployerComponent } from './add-employer/add-employer.component';
import { ListEmployerComponent } from './list-employer/list-employer.component';
import { ViewEmployerComponent } from './view-employer/view-employer.component';
import { EditComponentComponent } from './edit-component/edit-component.component';


const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'register', component: AddEmployerComponent},
  {path: 'list', component: ListEmployerComponent},
  {path:'viewEmployer', component: ViewEmployerComponent},
  {path:'editEmployer', component: EditComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
