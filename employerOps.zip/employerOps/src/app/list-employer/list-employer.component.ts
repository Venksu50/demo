import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Employer } from '../employer.model';
import { EmployService } from '../employer.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-list-employer',
  templateUrl: `./list-employer.component.html`,
  styleUrls: [`./list-employer.component.css`]
})
export class ListEmployerComponent implements OnInit 
{
  employers: Observable<Employer[]>;
  constructor(private service: EmployService, private router: Router, private cDS:ChangeDetectorRef) { 
  }

  ngOnInit(): void {
    this.fetchEmployers();
  }

  fetchEmployers()
  {
    this.service.getEmployer().subscribe( data =>
      {
        this.employers = data;
        this.cDS.markForCheck();
      });
  }

  viewEmployer(employerId: number)
  {
    this.service.viewParameter = employerId;
    this.router.navigate(['/viewEmployer']); 
  }

  editEmployer(employerId: number)
  {
    this.service.editParameter = employerId;
    this.router.navigate(["/editEmployer"]);
  }
}
